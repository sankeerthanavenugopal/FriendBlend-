All your outputs should be stored appropriately here. If you have multiple results for a single input, create appropriate folder/naming nomenclature and save it here.

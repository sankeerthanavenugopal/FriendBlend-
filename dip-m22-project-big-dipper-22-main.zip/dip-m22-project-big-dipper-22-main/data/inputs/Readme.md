All your input data should be present here. Images/Videos/Text Files everything that is an input.

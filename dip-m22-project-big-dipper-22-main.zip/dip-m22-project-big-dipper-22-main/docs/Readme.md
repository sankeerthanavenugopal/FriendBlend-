Documentation of the project can be found [here](https://www.notion.so/Friend-Blend-Documentation-eb0e980be417494b87dfb75998c361b6).

Presentation for the final evals can be found [here](https://www.canva.com/design/DAFTP2PEPIU/NLc7W1nEgJseUAxFOcr0og/view?utm_content=DAFTP2PEPIU&utm_campaign=designshare&utm_medium=link&utm_source=publishpresent) 
(They are here since the presentation was too big to upload to the repository)